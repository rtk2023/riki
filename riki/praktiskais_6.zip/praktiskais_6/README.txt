Edienu planotajs

Ievads

�is riks palidz lietotajiem planot savas edienreizes nedelai un automatiski izveidot iepirkumu sarakstu.

Parskats

Projekts ir izveidots ka vienkar�a timekla lietotne, izmantojot HTML, CSS un JavaScript.

Funkcionalitate:

Apskatit da�adus edienus (brokastis, pusdienas, vakarinas)
Pievienot edienus nedelas planam
Automatiski generet iepirkumu sarakstu
Atzimet produktus ka nopirktus
Dzest edienus no plana un produktus no saraksta
Atvert receptes (Google mekle�ana)

Arhitektura:

index.html � struktura
style.css � dizains un responsivitate
script.js � logika un datu apstrade

Datu strukturas:

`Edieni` � visi edieni ar sastavdalam
`Nedelas plans` � nedelas plans
`Iepirkumu saraksts` � iepirkumu saraksts

Iespejamie uzlabojumi

Saglaba�ana (localStorage)
Lietotaja pa�a edienu pievieno�ana
Kaloriju aprekins
Filtre�ana pec dietas (vegans, bez glutena)
Drag & drop plano�ana

Zinamie defekti

Dati netiek saglabati pec lapas parlades
Nav validacijas dubultiem edieniem
Nav lietotaja ievades iespeju

Resursi

https://developer.mozilla.org/
https://www.w3schools.com/
https://pagespeed.web.dev/
https://validator.w3.org/

Autors

Jekabs Zujevs
