function calculateProbability() {
    const numRolls = document.getElementById('numRolls').value;
    const desiredNumber = document.getElementById('desiredNumber').value;

    if (numRolls < 1 || desiredNumber < 1 || desiredNumber > 6) {
        alert("Lūdzu ievadiet derīgas vērtības.");
        return;
    }

    const probability = 1 / 6;
    const notDesiredProbability = 1 - probability;
    const result = (1 - Math.pow(notDesiredProbability, numRolls)) * 100;

    document.getElementById('result').innerText = `Varbūtība, ka skaitlis ${desiredNumber} uzkritīs vismaz vienreiz, ja kauliņu metīs ${numRolls} reizes, ir ${result.toFixed(2)}%`;
}
