Izveidoju metamā kauliņa varbūtību uzmest kādu no izvēlētajiem skaitļiem.
