const userInput = document.getElementById('userInput');

function generatePassword() {

}

function toggleSubCategory() {
  var checkbox = document.getElementById('option1Checkbox');
  var subCategory = document.getElementById('subCategory1');

  if (checkbox.checked) {
    subCategory.style.display = '';
  } else {
    subCategory.style.display = 'none';
  }
}
